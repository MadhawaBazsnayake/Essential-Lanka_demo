<?php include 'includes/header.php'; ?>

<style>
    /* ============================================
       ENHANCED ANIMATIONS & KEYFRAMES
       ============================================ */
    @keyframes float {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(2deg); }
    }
    @keyframes float-delayed {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-15px) rotate(-2deg); }
    }
    @keyframes pulse-glow {
        0%, 100% { box-shadow: 0 0 20px rgba(16,185,129,0.3); }
        50% { box-shadow: 0 0 40px rgba(16,185,129,0.6), 0 0 60px rgba(16,185,129,0.2); }
    }
    @keyframes gradient-shift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    @keyframes blob-morph {
        0%, 100% { border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%; }
        25% { border-radius: 30% 60% 70% 40% / 50% 60% 30% 60%; }
        50% { border-radius: 50% 60% 30% 60% / 30% 60% 70% 40%; }
        75% { border-radius: 60% 40% 60% 30% / 60% 30% 40% 70%; }
    }
    @keyframes fade-in-up {
        from { opacity: 0; transform: translateY(40px); }
        to { opacity: 1; transform: translateY(0); }
    }
    @keyframes scale-in {
        from { opacity: 0; transform: scale(0.8); }
        to { opacity: 1; transform: scale(1); }
    }
    @keyframes slide-in-left {
        from { opacity: 0; transform: translateX(-60px); }
        to { opacity: 1; transform: translateX(0); }
    }
    @keyframes slide-in-right {
        from { opacity: 0; transform: translateX(60px); }
        to { opacity: 1; transform: translateX(0); }
    }
    @keyframes rotate-slow {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    @keyframes bounce-soft {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink {
        50% { border-color: transparent; }
    }

    /* ============================================
       BASE ENHANCEMENTS
       ============================================ */
    :root {
        --accent-green: #10b981;
        --accent-green-dark: #059669;
        --accent-blue: #3b82f6;
        --accent-purple: #8b5cf6;
        --accent-orange: #f97316;
        --text-muted: #6b7280;
        --bg-cream: #fefce8;
        --glass-bg: rgba(255, 255, 255, 0.7);
        --glass-border: rgba(255, 255, 255, 0.5);
    }

    /* ============================================
       HERO SECTION - ENHANCED
       ============================================ */
    .hero {
        position: relative;
        overflow: hidden;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #fefce8 0%, #ecfdf5 50%, #fefce8 100%);
        background-size: 400% 400%;
        animation: gradient-shift 15s ease infinite;
    }

    .hero::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(16,185,129,0.05) 0%, transparent 70%);
        animation: rotate-slow 60s linear infinite;
        pointer-events: none;
    }

    .blob-bg {
        position: absolute;
        width: 600px;
        height: 600px;
        background: linear-gradient(135deg, rgba(16,185,129,0.15), rgba(59,130,246,0.15));
        border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%;
        animation: blob-morph 10s ease-in-out infinite;
        filter: blur(60px);
        z-index: 0;
        top: 10%;
        right: -10%;
    }

    .blob-bg::after {
        content: '';
        position: absolute;
        width: 400px;
        height: 400px;
        background: linear-gradient(135deg, rgba(139,92,246,0.1), rgba(249,115,22,0.1));
        border-radius: 40% 60% 70% 30% / 40% 50% 60% 50%;
        animation: blob-morph 12s ease-in-out infinite reverse;
        filter: blur(50px);
        bottom: -100px;
        left: -100px;
    }

    .hero-content {
        position: relative;
        z-index: 10;
        text-align: center;
        max-width: 900px;
        padding: 0 20px;
    }

    .massive-text {
        font-size: clamp(2.5rem, 6vw, 4.5rem);
        font-weight: 900;
        line-height: 1.1;
        color: #1f2937;
        margin-bottom: 20px;
        opacity: 0;
        animation: fade-in-up 1s ease forwards;
    }

    .massive-text .gradient-text {
        background: linear-gradient(135deg, var(--accent-green), var(--accent-blue), var(--accent-purple));
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: gradient-shift 3s ease infinite;
    }

    .pill-image {
        display: inline-block;
        width: 80px;
        height: 40px;
        border-radius: 50px;
        background-size: cover;
        background-position: center;
        vertical-align: middle;
        margin: 0 10px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        animation: float 4s ease-in-out infinite;
        border: 3px solid white;
    }

    .hero-sub {
        font-size: clamp(1.1rem, 2.5vw, 1.5rem);
        color: var(--text-muted);
        margin-bottom: 40px;
        opacity: 0;
        animation: fade-in-up 1s ease 0.3s forwards;
        font-weight: 500;
    }

    .typing-effect {
        display: inline-block;
        overflow: hidden;
        border-right: 3px solid var(--accent-green);
        white-space: nowrap;
        animation: typing 3s steps(30) 1s forwards, blink 0.75s step-end infinite;
        max-width: fit-content;
    }

    /* ============================================
       COMPLEX SEARCH BOX - ENHANCED
       ============================================ */
    .complex-search {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px;
        border-radius: 50px;
        flex-wrap: wrap;
        gap: 8px;
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.6);
        box-shadow: 0 20px 60px rgba(0,0,0,0.1), 0 0 0 1px rgba(16,185,129,0.1);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        opacity: 0;
        animation: scale-in 0.8s ease 0.6s forwards;
    }

    .complex-search:focus-within {
        transform: translateY(-5px) scale(1.02);
        box-shadow: 0 25px 70px rgba(16,185,129,0.15), 0 0 0 2px rgba(16,185,129,0.2);
    }

    .search-input-group {
        display: flex;
        align-items: center;
        flex: 1;
        min-width: 200px;
        padding: 12px 20px;
        transition: all 0.3s ease;
    }

    .search-input-group:hover {
        background: rgba(16,185,129,0.03);
        border-radius: 40px;
    }

    .search-input-group input {
        width: 100%;
        border: none;
        background: transparent;
        outline: none;
        font-size: 1.05rem;
        margin-left: 12px;
        color: #374151;
        font-weight: 500;
    }

    .search-input-group input::placeholder {
        color: #9ca3af;
        transition: all 0.3s ease;
    }

    .search-input-group input:focus::placeholder {
        transform: translateX(5px);
        opacity: 0.7;
    }

    .search-icon {
        font-size: 1.3rem;
        color: var(--accent-green);
        transition: transform 0.3s ease;
    }

    .search-input-group:focus-within .search-icon {
        transform: scale(1.2) rotate(-10deg);
    }

    .search-divider {
        width: 1px;
        height: 35px;
        background: linear-gradient(to bottom, transparent, rgba(0,0,0,0.1), transparent);
        transition: all 0.3s ease;
    }

    .complex-search:focus-within .search-divider {
        background: linear-gradient(to bottom, transparent, rgba(16,185,129,0.3), transparent);
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--accent-green), var(--accent-green-dark));
        color: white;
        padding: 16px 40px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 1.05rem;
        border: none;
        cursor: pointer;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 10px 30px rgba(16,185,129,0.3);
        position: relative;
        overflow: hidden;
    }

    .btn-primary::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        transition: left 0.5s ease;
    }

    .btn-primary:hover {
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 15px 40px rgba(16,185,129,0.4);
    }

    .btn-primary:hover::before {
        left: 100%;
    }

    .btn-primary:active {
        transform: translateY(-1px) scale(1.02);
    }

    /* ============================================
       HERO BUTTONS - ENHANCED
       ============================================ */
    .hero-buttons-wrapper {
        display: flex;
        justify-content: center;
        gap: 20px;
        flex-wrap: wrap;
        margin-top: 50px;
        opacity: 0;
        animation: fade-in-up 1s ease 0.9s forwards;
    }

    .hero-btn-solid {
        background: linear-gradient(135deg, var(--accent-green), var(--accent-green-dark));
        color: white;
        padding: 16px 40px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 1.1rem;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 10px 25px rgba(16,185,129,0.3);
        border: none;
        display: inline-block;
        text-decoration: none;
        position: relative;
        overflow: hidden;
    }

    .hero-btn-solid::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        border-radius: 50%;
        background: rgba(255,255,255,0.2);
        transform: translate(-50%, -50%);
        transition: width 0.6s ease, height 0.6s ease;
    }

    .hero-btn-solid:hover {
        transform: translateY(-5px) scale(1.05);
        box-shadow: 0 20px 40px rgba(16,185,129,0.4);
        color: white;
    }

    .hero-btn-solid:hover::after {
        width: 300px;
        height: 300px;
    }

    .hero-btn-outline {
        background: transparent;
        color: var(--accent-green);
        padding: 14px 40px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 1.1rem;
        border: 2px solid var(--accent-green);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        display: inline-block;
        text-decoration: none;
        position: relative;
        overflow: hidden;
    }

    .hero-btn-outline::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 0;
        height: 100%;
        background: linear-gradient(135deg, var(--accent-green), var(--accent-green-dark));
        transition: width 0.4s ease;
        z-index: -1;
    }

    .hero-btn-outline:hover {
        color: white;
        transform: translateY(-5px) scale(1.05);
        box-shadow: 0 15px 35px rgba(16,185,129,0.3);
        border-color: transparent;
    }

    .hero-btn-outline:hover::before {
        width: 100%;
    }

    /* Floating particles */
    .particle {
        position: absolute;
        border-radius: 50%;
        background: rgba(16,185,129,0.2);
        pointer-events: none;
        animation: float linear infinite;
    }

    /* ============================================
       STATS SECTION - ENHANCED
       ============================================ */
    .stats-section {
        padding: 100px 0;
        position: relative;
        overflow: hidden;
    }

    .stats-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2310b981' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        opacity: 0.5;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 30px;
        text-align: center;
        position: relative;
        z-index: 10;
    }

    .stat-card {
        background: white;
        padding: 40px 25px;
        border-radius: 28px;
        box-shadow: 0 15px 40px rgba(0,0,0,0.06);
        transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(0,0,0,0.02);
        position: relative;
        overflow: hidden;
        opacity: 0;
        transform: translateY(30px);
    }

    .stat-card.visible {
        opacity: 1;
        transform: translateY(0);
    }

    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(16,185,129,0.05), transparent);
        transition: left 0.7s ease;
    }

    .stat-card:hover {
        transform: translateY(-15px) scale(1.05);
        box-shadow: 0 25px 60px rgba(16,185,129,0.15);
        border-color: rgba(16,185,129,0.2);
    }

    .stat-card:hover::before {
        left: 100%;
    }

    .stat-card h3 {
        font-size: 3rem;
        font-weight: 900;
        color: var(--accent-green);
        margin-bottom: 8px;
        display: flex;
        justify-content: center;
        align-items: center;
        line-height: 1;
    }

    .stat-card p {
        font-weight: 700;
        color: var(--text-muted);
        font-size: 1.1rem;
        letter-spacing: 0.5px;
    }

    .stat-icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
        display: inline-block;
        animation: bounce-soft 3s ease-in-out infinite;
    }

    /* ============================================
       SERVICES SECTION - ENHANCED
       ============================================ */
    .section-padding {
        padding: 100px 0;
        position: relative;
    }

    .section-header {
        margin-bottom: 60px;
    }

    .section-header h2 {
        font-size: clamp(2rem, 4vw, 3rem);
        font-weight: 900;
        color: #1f2937;
        position: relative;
        display: inline-block;
    }

    .section-header h2::after {
        content: '';
        position: absolute;
        bottom: -15px;
        left: 50%;
        transform: translateX(-50%);
        width: 60px;
        height: 4px;
        background: linear-gradient(135deg, var(--accent-green), var(--accent-blue));
        border-radius: 2px;
    }

    .cards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 30px;
    }

    .service-card {
        background: white;
        border-radius: 24px;
        padding: 35px 30px;
        position: relative;
        overflow: hidden;
        transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(0,0,0,0.04);
        box-shadow: 0 10px 40px rgba(0,0,0,0.05);
        opacity: 0;
        transform: translateY(40px);
    }

    .service-card.visible {
        opacity: 1;
        transform: translateY(0);
    }

    .service-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: linear-gradient(90deg, var(--accent-green), var(--accent-blue));
        transform: scaleX(0);
        transform-origin: left;
        transition: transform 0.5s ease;
    }

    .service-card:hover {
        transform: translateY(-15px) scale(1.03);
        box-shadow: 0 25px 60px rgba(0,0,0,0.12);
    }

    .service-card:hover::before {
        transform: scaleX(1);
    }

    .icon-box {
        width: 65px;
        height: 65px;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        margin-bottom: 20px;
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
    }

    .icon-box::after {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .service-card:hover .icon-box {
        transform: scale(1.15) rotate(5deg);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }

    .service-card:hover .icon-box::after {
        opacity: 1;
    }

    .icon-green { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #059669; }
    .icon-blue { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #2563eb; }
    .icon-purple { background: linear-gradient(135deg, #ede9fe, #ddd6fe); color: #7c3aed; }
    .icon-orange { background: linear-gradient(135deg, #ffedd5, #fed7aa); color: #ea580c; }

    .service-card h3 {
        font-size: 1.4rem;
        font-weight: 800;
        color: #1f2937;
        margin-bottom: 10px;
    }

    .service-card p {
        color: var(--text-muted);
        line-height: 1.6;
        font-size: 0.95rem;
    }

    .card-link {
        position: absolute;
        bottom: 25px;
        right: 25px;
        width: 45px;
        height: 45px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--accent-green), var(--accent-green-dark));
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 5px 15px rgba(16,185,129,0.3);
    }

    .card-link:hover {
        transform: scale(1.2) rotate(360deg);
        box-shadow: 0 8px 25px rgba(16,185,129,0.4);
    }

    /* ============================================
       HOW IT WORKS - ENHANCED
       ============================================ */
    .rounded-section {
        border-radius: 40px;
        padding: 80px 40px;
        background: white;
        box-shadow: 0 20px 60px rgba(0,0,0,0.05);
    }

    .badge-pill {
        display: inline-block;
        padding: 8px 20px;
        border-radius: 50px;
        font-weight: 700;
        font-size: 0.9rem;
        margin-bottom: 20px;
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    .process-steps {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 40px;
        margin-top: 50px;
    }

    .step {
        text-align: center;
        padding: 30px;
        position: relative;
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.6s ease;
    }

    .step.visible {
        opacity: 1;
        transform: translateY(0);
    }

    .step:not(:last-child)::after {
        content: '';
        position: absolute;
        top: 50px;
        right: -20px;
        width: 40px;
        height: 2px;
        background: linear-gradient(90deg, var(--accent-green), transparent);
        display: none;
    }

    @media (min-width: 768px) {
        .step:not(:last-child)::after {
            display: block;
        }
    }

    .step-icon {
        width: 90px;
        height: 90px;
        border-radius: 50%;
        background: linear-gradient(135deg, #ecfdf5, #d1fae5);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.2rem;
        color: var(--accent-green);
        margin: 0 auto 25px;
        position: relative;
        transition: all 0.4s ease;
        box-shadow: 0 10px 30px rgba(16,185,129,0.15);
    }

    .step-icon::before {
        content: '';
        position: absolute;
        inset: -5px;
        border-radius: 50%;
        border: 2px dashed rgba(16,185,129,0.3);
        animation: rotate-slow 20s linear infinite;
    }

    .step:hover .step-icon {
        transform: scale(1.15) translateY(-5px);
        box-shadow: 0 15px 40px rgba(16,185,129,0.25);
    }

    .step h4 {
        font-size: 1.3rem;
        font-weight: 800;
        color: #1f2937;
        margin-bottom: 12px;
    }

    .step p {
        color: var(--text-muted);
        line-height: 1.7;
        font-size: 0.95rem;
    }

    /* ============================================
       SAFETY SECTION - ENHANCED
       ============================================ */
    .bg-dark {
        background: linear-gradient(135deg, #111827 0%, #1f2937 50%, #111827 100%);
        position: relative;
        overflow: hidden;
    }

    .bg-dark::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 600px;
        height: 600px;
        background: radial-gradient(circle, rgba(16,185,129,0.1) 0%, transparent 70%);
        border-radius: 50%;
    }

    .grid-2-col {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 60px;
        align-items: center;
    }

    .info-text h2 {
        font-size: clamp(2rem, 4vw, 2.8rem);
        font-weight: 900;
        color: white;
        margin-bottom: 30px;
        line-height: 1.2;
    }

    .feature-list-large {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .feature-list-large li {
        padding: 18px 0;
        font-size: 1.15rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 15px;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        transition: all 0.3s ease;
        opacity: 0;
        transform: translateX(-30px);
    }

    .feature-list-large li.visible {
        opacity: 1;
        transform: translateX(0);
    }

    .feature-list-large li:hover {
        padding-left: 10px;
        color: var(--accent-green);
    }

    .feature-list-large li i {
        font-size: 1.4rem;
        transition: transform 0.3s ease;
    }

    .feature-list-large li:hover i {
        transform: scale(1.3);
    }

    .trust-image-wrapper {
        position: relative;
        opacity: 0;
        transform: translateX(50px);
        transition: all 0.8s ease;
    }

    .trust-image-wrapper.visible {
        opacity: 1;
        transform: translateX(0);
    }

    .trust-image-wrapper img {
        width: 100%;
        border-radius: 24px;
        box-shadow: 0 25px 60px rgba(0,0,0,0.3);
        transition: all 0.5s ease;
    }

    .trust-image-wrapper:hover img {
        transform: scale(1.03);
        box-shadow: 0 30px 70px rgba(0,0,0,0.4);
    }

    .text-green { color: var(--accent-green); }

    /* ============================================
       REVIEWS SECTION - ENHANCED
       ============================================ */
    .reviews-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 30px;
        margin-top: 50px;
    }

    .review-card {
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.6);
        border-radius: 28px;
        padding: 40px 35px;
        text-align: center;
        position: relative;
        overflow: hidden;
        transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 15px 40px rgba(0,0,0,0.06);
        opacity: 0;
        transform: translateY(40px) scale(0.95);
    }

    .review-card.visible {
        opacity: 1;
        transform: translateY(0) scale(1);
    }

    .review-card::before {
        content: '"';
        position: absolute;
        top: 20px;
        left: 25px;
        font-size: 5rem;
        color: rgba(16,185,129,0.1);
        font-family: Georgia, serif;
        line-height: 1;
        pointer-events: none;
    }

    .review-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 25px 60px rgba(0,0,0,0.1);
        border-color: rgba(16,185,129,0.2);
    }

    .stars {
        color: #fbbf24;
        margin-bottom: 20px;
        font-size: 1.4rem;
        letter-spacing: 3px;
    }

    .review-text {
        font-size: 1.1rem;
        font-weight: 500;
        font-style: italic;
        color: #374151;
        line-height: 1.8;
        margin-bottom: 25px;
        position: relative;
        z-index: 1;
    }

    .review-card h5 {
        font-weight: 700;
        color: #9ca3af;
        font-size: 0.95rem;
        letter-spacing: 0.5px;
    }

    .review-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        margin: 0 auto 15px;
        background: linear-gradient(135deg, var(--accent-green), var(--accent-blue));
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 800;
        font-size: 1.3rem;
        box-shadow: 0 5px 20px rgba(16,185,129,0.3);
    }

    /* ============================================
       WORKER CTA BANNER - ENHANCED
       ============================================ */
    .worker-cta-banner {
        background: linear-gradient(135deg, #10b981 0%, #059669 40%, #047857 100%);
        background-size: 200% 200%;
        animation: gradient-shift 8s ease infinite;
        color: white;
        padding: 80px 5%;
        border-radius: 40px;
        text-align: center;
        box-shadow: 0 30px 60px rgba(16,185,129,0.25);
        position: relative;
        overflow: hidden;
        opacity: 0;
        transform: translateY(40px) scale(0.98);
        transition: all 0.8s ease;
    }

    .worker-cta-banner.visible {
        opacity: 1;
        transform: translateY(0) scale(1);
    }

    .worker-cta-banner::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 60%);
        animation: rotate-slow 30s linear infinite;
    }

    .worker-cta-banner::after {
        content: '';
        position: absolute;
        inset: 0;
        background: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");
        opacity: 0.3;
    }

    .worker-cta-banner h2 {
        font-size: clamp(2rem, 4vw, 2.8rem);
        font-weight: 900;
        margin-bottom: 20px;
        position: relative;
        z-index: 1;
        text-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .worker-cta-banner p {
        font-size: 1.2rem;
        opacity: 0.95;
        margin-bottom: 40px;
        position: relative;
        z-index: 1;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }

    .worker-cta-banner .ph-briefcase {
        position: relative;
        z-index: 1;
        animation: float 3s ease-in-out infinite;
        display: inline-block;
    }

    .cta-buttons-wrapper {
        display: flex;
        justify-content: center;
        gap: 20px;
        flex-wrap: wrap;
        position: relative;
        z-index: 1;
    }

    .btn-solid-white {
        background: #ffffff !important;
        color: #059669 !important;
        padding: 16px 40px !important;
        border-radius: 50px !important;
        font-weight: 800 !important;
        font-size: 1.1rem !important;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        border: none !important;
        text-decoration: none;
        display: inline-block;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        position: relative;
        overflow: hidden;
    }

    .btn-solid-white:hover {
        transform: translateY(-5px) scale(1.05) !important;
        box-shadow: 0 15px 40px rgba(0,0,0,0.2) !important;
    }

    .btn-outline-white {
        background: transparent !important;
        color: #ffffff !important;
        padding: 14px 40px !important;
        border-radius: 50px !important;
        font-weight: 800 !important;
        font-size: 1.1rem !important;
        border: 2px solid rgba(255,255,255,0.8) !important;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        text-decoration: none;
        display: inline-block;
        position: relative;
        overflow: hidden;
    }

    .btn-outline-white:hover {
        background: rgba(255,255,255,0.15) !important;
        transform: translateY(-5px) scale(1.05) !important;
        border-color: #ffffff !important;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1) !important;
    }

    /* ============================================
       SCROLL REVEAL UTILITIES
       ============================================ */
    .reveal {
        opacity: 0;
        transform: translateY(40px);
        transition: all 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .reveal.visible {
        opacity: 1;
        transform: translateY(0);
    }

    .reveal-left {
        opacity: 0;
        transform: translateX(-60px);
        transition: all 0.8s ease;
    }

    .reveal-left.visible {
        opacity: 1;
        transform: translateX(0);
    }

    .reveal-right {
        opacity: 0;
        transform: translateX(60px);
        transition: all 0.8s ease;
    }

    .reveal-right.visible {
        opacity: 1;
        transform: translateX(0);
    }

    .reveal-scale {
        opacity: 0;
        transform: scale(0.8);
        transition: all 0.8s ease;
    }

    .reveal-scale.visible {
        opacity: 1;
        transform: scale(1);
    }

    /* ============================================
       MOBILE RESPONSIVENESS - ENHANCED
       ============================================ */
    @media (max-width: 768px) {
        .hero { min-height: auto; padding: 80px 0; }
        .blob-bg { width: 300px; height: 300px; opacity: 0.5; }
        .complex-search { flex-direction: column; border-radius: 24px; padding: 15px; }
        .search-divider { width: 100%; height: 1px; margin: 5px 0; }
        .hero-btn-solid, .hero-btn-outline { width: 100%; text-align: center; }
        .hero-buttons-wrapper { flex-direction: column; gap: 15px; margin-top: 35px; }
        .stats-section { padding: 60px 0; }
        .stats-grid { grid-template-columns: 1fr 1fr; gap: 15px; }
        .stat-card { padding: 25px 15px; }
        .stat-card h3 { font-size: 2rem; }
        .grid-2-col { grid-template-columns: 1fr; gap: 40px; }
        .rounded-section { padding: 50px 25px; border-radius: 24px; }
        .process-steps { gap: 30px; }
        .step:not(:last-child)::after { display: none; }
        .reviews-grid { grid-template-columns: 1fr; }
        .worker-cta-banner { padding: 50px 25px; border-radius: 24px; }
        .worker-cta-banner h2 { font-size: 1.8rem; }
        .cta-buttons-wrapper { flex-direction: column; }
        .section-padding { padding: 60px 0; }
        .cards-grid { grid-template-columns: 1fr; }
    }

    @media (max-width: 480px) {
        .stats-grid { grid-template-columns: 1fr; }
        .massive-text { font-size: 2rem; }
        .pill-image { width: 60px; height: 30px; }
    }

    /* Smooth scrolling */
    html { scroll-behavior: smooth; }

    /* Custom scrollbar */
    ::-webkit-scrollbar { width: 10px; }
    ::-webkit-scrollbar-track { background: #f1f1f1; }
    ::-webkit-scrollbar-thumb { background: linear-gradient(135deg, var(--accent-green), var(--accent-green-dark)); border-radius: 5px; }
    ::-webkit-scrollbar-thumb:hover { background: var(--accent-green-dark); }
</style>

<section class="hero">
    <div class="blob-bg"></div>
    <!-- Floating particles -->
    <div class="particle" style="width: 10px; height: 10px; top: 20%; left: 10%; animation-duration: 8s; animation-delay: 0s;"></div>
    <div class="particle" style="width: 15px; height: 15px; top: 60%; left: 80%; animation-duration: 10s; animation-delay: 2s;"></div>
    <div class="particle" style="width: 8px; height: 8px; top: 40%; left: 90%; animation-duration: 7s; animation-delay: 1s;"></div>
    <div class="particle" style="width: 12px; height: 12px; top: 80%; left: 20%; animation-duration: 9s; animation-delay: 3s;"></div>
    <div class="particle" style="width: 6px; height: 6px; top: 30%; left: 50%; animation-duration: 11s; animation-delay: 4s;"></div>

    <div class="hero-content">
        <h1 class="massive-text">
            Essential Lanka <br>
            <span class="pill-image" style="background-image: url('https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=600&auto=format&fit=crop');"></span> 
            <span class="gradient-text">is Support.</span>
        </h1>
        <p class="hero-sub">
            <span class="typing-effect">What service do you need today?</span>
        </p>
        
        <div class="quick-search" style="max-width: 850px; margin: 0 auto;">
            <form action="services.php" method="GET" class="complex-search">
                <div class="search-input-group">
                    <i class="ph ph-magnifying-glass search-icon"></i>
                    <input type="text" name="q" placeholder='"Electrician", "Plumber", "Painter"...' required>
                </div>
                <div class="search-divider"></div>
                <div class="search-input-group">
                    <i class="ph-fill ph-map-pin text-red search-icon" style="color: #ef4444;"></i>
                    <input type="text" name="location" placeholder="Your Location" required>
                </div>
                <button type="submit" class="btn-primary">Search Workers</button>
            </form>
        </div>

        <div class="hero-buttons-wrapper">
            <a href="register.php?role=worker" class="hero-btn-solid">
                <i class="ph-fill ph-wrench" style="margin-right: 8px;"></i>Join as a Worker
            </a>
            <a href="register.php?role=client" class="hero-btn-outline">
                <i class="ph-fill ph-user" style="margin-right: 8px;"></i>Join as a Customer
            </a>
        </div>
    </div>
</section>

<section class="bg-cream stats-section">
    <div class="grid-container">
        <div class="stats-grid">
            <div class="stat-card reveal">
                <div class="stat-icon"><i class="ph-fill ph-users"></i></div>
                <h3><span class="counter" data-target="10000">0</span>+</h3>
                <p>Verified Workers</p>
            </div>
            <div class="stat-card reveal" style="transition-delay: 100ms;">
                <div class="stat-icon"><i class="ph-fill ph-check-circle" style="color: var(--accent-blue);"></i></div>
                <h3><span class="counter" data-target="25000">0</span>+</h3>
                <p>Jobs Completed</p>
            </div>
            <div class="stat-card reveal" style="transition-delay: 200ms;">
                <div class="stat-icon"><i class="ph-fill ph-grid-four" style="color: var(--accent-purple);"></i></div>
                <h3><span class="counter" data-target="100">0</span>+</h3>
                <p>Service Categories</p>
            </div>
            <div class="stat-card reveal" style="transition-delay: 300ms;">
                <div class="stat-icon"><i class="ph-fill ph-headset" style="color: var(--accent-orange);"></i></div>
                <h3 style="color: var(--accent-blue); font-size: 2.5rem;">24/7</h3>
                <p>Support</p>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-white" id="services">
    <div class="grid-container">
        <div class="section-header text-center reveal">
            <h2>Popular Services</h2>
        </div>
        <div class="cards-grid">
            <div class="service-card reveal">
                <div class="card-content">
                    <div class="icon-box icon-green"><i class="ph-fill ph-lightning"></i></div>
                    <h3>Electrical</h3>
                    <p class="mt-2">Wiring, installations, and repairs by certified professionals.</p>
                </div>
                <a href="services.php" class="card-link"><i class="ph ph-arrow-right"></i></a>
            </div>
            <div class="service-card reveal" style="transition-delay: 100ms;">
                <div class="card-content">
                    <div class="icon-box icon-blue"><i class="ph-fill ph-drop"></i></div>
                    <h3>Plumbing</h3>
                    <p class="mt-2">Leak fixes, pipe laying, and maintenance services.</p>
                </div>
                <a href="services.php" class="card-link"><i class="ph ph-arrow-right"></i></a>
            </div>
            <div class="service-card reveal" style="transition-delay: 200ms;">
                <div class="card-content">
                    <div class="icon-box icon-purple"><i class="ph-fill ph-broom"></i></div>
                    <h3>Cleaning</h3>
                    <p class="mt-2">Deep house cleaning and professional organizing.</p>
                </div>
                <a href="services.php" class="card-link"><i class="ph ph-arrow-right"></i></a>
            </div>
            <div class="service-card reveal" style="transition-delay: 300ms;">
                <div class="card-content">
                    <div class="icon-box icon-orange"><i class="ph-fill ph-paint-roller"></i></div>
                    <h3>Painting</h3>
                    <p class="mt-2">Interior and exterior house painting services.</p>
                </div>
                <a href="services.php" class="card-link"><i class="ph ph-arrow-right"></i></a>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-cream" id="how-it-works">
    <div class="grid-container rounded-section">
        <div class="section-header text-center reveal">
            <span class="badge-pill" style="color:var(--accent-green); background: rgba(16,185,129,0.1);">Process</span>
            <h2>How It Works</h2>
        </div>
        <div class="process-steps">
            <div class="step reveal">
                <div class="step-icon"><i class="ph-fill ph-map-pin"></i></div>
                <h4>1. Search & Match</h4>
                <p>Use GPS to find verified workers near your location instantly.</p>
            </div>
            <div class="step reveal" style="transition-delay: 150ms;">
                <div class="step-icon"><i class="ph-fill ph-chat-circle-text"></i></div>
                <h4>2. Accept & Chat</h4>
                <p>Compare bids and chat securely within the app.</p>
            </div>
            <div class="step reveal" style="transition-delay: 300ms;">
                <div class="step-icon"><i class="ph-fill ph-check-circle"></i></div>
                <h4>3. Job Done</h4>
                <p>Pay securely and leave a star rating for the worker.</p>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-dark rounded-section mt-5 mx-2" id="safety">
    <div class="grid-2-col">
        <div class="info-text reveal-left">
            <h2 class="mb-4">Your Safety Matters</h2>
            <ul class="feature-list-large trust-spacing-fix">
                <li><i class="ph-fill ph-check-circle text-green"></i> Identity Verified Workers</li>
                <li><i class="ph-fill ph-lock-key text-green"></i> Secure Communication</li>
                <li><i class="ph-fill ph-star text-green"></i> Review System</li>
                <li><i class="ph-fill ph-scales text-green"></i> Dispute Resolution</li>
                <li><i class="ph-fill ph-shield-check text-green"></i> Safe Payments</li>
            </ul>
        </div>
        <div class="trust-image-wrapper reveal-right">
            <img src="https://images.unsplash.com/photo-1573164713988-8665fc963095?q=80&w=600&auto=format&fit=crop" class="rounded-image shadow-lg" alt="Safety">
        </div>
    </div>
</section>

<section class="section-padding bg-cream">
    <div class="grid-container">
        <div class="section-header text-center reveal">
            <h2>Customer Feedback</h2>
        </div>
        <div class="reviews-grid">
            <div class="review-card reveal">
                <div class="review-avatar">N</div>
                <div class="stars mb-3"><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i></div>
                <p class="review-text">"Found a plumber within 20 minutes. Very professional service and fair pricing!"</p>
                <h5 class="mt-4">- Nimal, Colombo</h5>
            </div>
            
            <div class="review-card reveal" style="transition-delay: 150ms;">
                <div class="review-avatar" style="background: linear-gradient(135deg, var(--accent-purple), var(--accent-blue));">S</div>
                <div class="stars mb-3"><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i></div>
                <p class="review-text">"Super easy to use. The electrician arrived on time and fixed the issue fast."</p>
                <h5 class="mt-4">- Sarah, Dehiwala</h5>
            </div>
            
            <div class="review-card reveal" style="transition-delay: 300ms;">
                <div class="review-avatar" style="background: linear-gradient(135deg, var(--accent-orange), #f59e0b);">D</div>
                <div class="stars mb-3"><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star"></i><i class="ph-fill ph-star-half"></i></div>
                <p class="review-text">"Great platform to find trusted daily workers without any middlemen."</p>
                <h5 class="mt-4">- Dinesh, Kandy</h5>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-cream pt-0">
    <div class="grid-container">
        <div class="worker-cta-banner reveal-scale">
            <i class="ph-fill ph-briefcase" style="font-size: 4rem; margin-bottom: 20px; color: rgba(255,255,255,0.9);"></i>
            <h2>Have a Skill? Earn Money From Your Skills</h2>
            <p>Join thousands of Sri Lankan workers earning daily on our platform. Turn your expertise into income.</p>
            
            <div class="cta-buttons-wrapper mt-4">
                <a href="register.php?role=worker" class="btn-solid-white">
                    <i class="ph-fill ph-wrench" style="margin-right: 8px;"></i>Join as a Worker
                </a>
                <a href="register.php?role=client" class="btn-outline-white">
                    <i class="ph-fill ph-user" style="margin-right: 8px;"></i>Join as a Customer
                </a>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener("DOMContentLoaded", () => {
    // ============================================
    // COUNTER ANIMATION WITH EASING
    // ============================================
    const counters = document.querySelectorAll('.counter');
    const speed = 150;

    const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);

    const startCounting = (counter) => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000;
        const startTime = performance.now();

        const updateCount = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easedProgress = easeOutQuart(progress);
            const current = Math.floor(easedProgress * target);

            counter.innerText = current.toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(updateCount);
            } else {
                counter.innerText = target.toLocaleString();
            }
        };

        requestAnimationFrame(updateCount);
    };

    // ============================================
    // INTERSECTION OBSERVER - SCROLL REVEALS
    // ============================================
    const observerOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    };

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Trigger counters if inside stat cards
                const counter = entry.target.querySelector('.counter');
                if (counter && !counter.classList.contains('counted')) {
                    counter.classList.add('counted');
                    startCounting(counter);
                }
                
                // Stagger list items
                const listItems = entry.target.querySelectorAll('.feature-list-large li');
                listItems.forEach((item, index) => {
                    setTimeout(() => item.classList.add('visible'), index * 100);
                });
            }
        });
    }, observerOptions);

    // Observe all reveal elements
    document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale, .stat-card, .service-card, .step, .review-card, .worker-cta-banner').forEach(el => {
        revealObserver.observe(el);
    });

    // ============================================
    // PARALLAX EFFECT ON HERO
    // ============================================
    const hero = document.querySelector('.hero');
    const blob = document.querySelector('.blob-bg');
    
    if (hero && blob) {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * 0.3;
            blob.style.transform = `translateY(${rate}px)`;
        });
    }

    // ============================================
    // MOUSE MOVE EFFECT ON CARDS
    // ============================================
    document.querySelectorAll('.service-card, .stat-card, .review-card').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            card.style.setProperty('--mouse-x', `${x}px`);
            card.style.setProperty('--mouse-y', `${y}px`);
        });
    });

    // ============================================
    // NAVBAR SCROLL EFFECT (if navbar exists)
    // ============================================
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        const navbar = document.querySelector('nav, .navbar, header');
        
        if (navbar) {
            if (currentScroll > 100) {
                navbar.style.backdropFilter = 'blur(20px)';
                navbar.style.background = 'rgba(255,255,255,0.9)';
                navbar.style.boxShadow = '0 4px 20px rgba(0,0,0,0.08)';
            } else {
                navbar.style.backdropFilter = 'none';
                navbar.style.background = 'transparent';
                navbar.style.boxShadow = 'none';
            }
        }
        
        lastScroll = currentScroll;
    });

    // ============================================
    // SMOOTH ANCHOR SCROLLING
    // ============================================
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // ============================================
    // BUTTON RIPPLE EFFECT
    // ============================================
    document.querySelectorAll('.hero-btn-solid, .hero-btn-outline, .btn-primary, .btn-solid-white, .btn-outline-white').forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                background: rgba(255,255,255,0.3);
                border-radius: 50%;
                transform: scale(0);
                animation: ripple 0.6s ease-out;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });

    // Add ripple keyframe dynamically
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to { transform: scale(2); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
});
</script>

<?php include 'includes/footer.php'; ?>