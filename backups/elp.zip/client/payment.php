<?php
// client/payment.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'client') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Payment - Essential Lanka</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<style>
    .page-section { padding: 50px 5%; min-height: 85vh; position: relative; }
    .page-container { max-width: 850px; margin: 0 auto; position: relative; z-index: 10; }
    
    .header-action { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
    .back-btn { display: inline-flex; align-items: center; gap: 8px; color: #666; text-decoration: none; font-weight: 700; transition: 0.3s; font-size: 1.05rem; }
    .back-btn:hover { color: #10b981; }
    .page-title { font-size: 2.2rem; font-weight: 800; color: #1a1a1a; }

    .glass-box { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px); border: 1px solid rgba(255, 255, 255, 0.9); box-shadow: 0 15px 40px rgba(0,0,0,0.06); padding: 40px; border-radius: 35px; }
    
    /* Order Summary */
    .order-summary { background: #f8fafc; border: 1px dashed #cbd5e1; padding: 25px; border-radius: 20px; margin-bottom: 35px; }
    .summary-row { display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 1.05rem; color: #475569; }
    .summary-row:last-child { margin-bottom: 0; padding-top: 15px; border-top: 2px solid #e2e8f0; font-weight: 800; font-size: 1.3rem; color: #1a1a1a; }

    /* Payment Methods Toggle */
    .payment-methods { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
    .method-card { background: #ffffff; border: 2px solid #e5dfd5; padding: 20px; border-radius: 20px; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 10px; transition: 0.3s; position: relative; }
    .method-card i { font-size: 2.5rem; color: #a3a3a3; transition: 0.3s; }
    .method-card span { font-weight: 700; color: #666; transition: 0.3s; }
    .method-card input[type="radio"] { display: none; }
    
    .method-card.active { border-color: #10b981; background: rgba(16, 185, 129, 0.05); box-shadow: 0 10px 25px rgba(16,185,129,0.1); }
    .method-card.active i { color: #10b981; }
    .method-card.active span { color: #10b981; }
    
    .check-icon { position: absolute; top: 15px; right: 15px; color: #10b981; font-size: 1.5rem; opacity: 0; transition: 0.3s; }
    .method-card.active .check-icon { opacity: 1; }

    /* Card Details Form */
    .card-details-section { max-height: 500px; overflow: hidden; opacity: 1; transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    .card-details-section.hidden { max-height: 0; opacity: 0; margin: 0; padding: 0; overflow: hidden; }

    .form-group { margin-bottom: 22px; text-align: left; }
    .form-group label { display: block; font-weight: 700; margin-bottom: 8px; font-size: 0.95rem; color: #1a1a1a; }
    .form-control { width: 100%; padding: 15px 20px; border-radius: 18px; border: 2px solid #e5dfd5; background: #ffffff; font-size: 1rem; transition: 0.3s; outline: none; font-weight: 500; }
    .form-control:focus { border-color: #10b981; box-shadow: 0 0 0 4px rgba(16,185,129,0.1); }
    .d-flex-gap { display: flex; gap: 15px; }
    .d-flex-gap .form-group { flex: 1; }

    .btn-submit { background: #10b981; color: white; padding: 18px; border-radius: 50px; font-weight: 800; border: none; cursor: pointer; transition: 0.3s; width: 100%; font-size: 1.15rem; box-shadow: 0 10px 25px rgba(16,185,129,0.2); margin-top: 15px; display: flex; justify-content: center; align-items: center; gap: 10px; }
    .btn-submit:hover { transform: translateY(-3px); box-shadow: 0 15px 35px rgba(16,185,129,0.3); }

    /* Demo overlay alert */
    .demo-alert { background: rgba(59, 130, 246, 0.1); color: #2563eb; padding: 12px 20px; border-radius: 15px; font-weight: 600; font-size: 0.9rem; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }

    @media (max-width: 768px) {
        .payment-methods { grid-template-columns: 1fr; }
        .d-flex-gap { flex-direction: column; gap: 0; }
        .glass-box { padding: 30px 20px; }
    }
</style>

<section class="page-section bg-cream">
    <div class="blob-bg"></div>
    
    <div class="page-container">
        
        <div class="header-action fade-up show">
            <h1 class="page-title">Complete Payment</h1>
            <a href="active-jobs.php" class="back-btn"><i class="ph-bold ph-arrow-left"></i> Back to Jobs</a>
        </div>

        <div class="glass-box fade-up show" style="transition-delay: 100ms;">
            
            <div class="demo-alert">
                <i class="ph-fill ph-info"></i> This is a Demo environment. No actual charges will be made to your card.
            </div>

            <!-- Job Summary -->
            <div class="order-summary">
                <div class="summary-row">
                    <span>Service:</span>
                    <span style="font-weight: 700;">Electrical Wiring Repair</span>
                </div>
                <div class="summary-row">
                    <span>Worker:</span>
                    <span>Saman Kumara</span>
                </div>
                <div class="summary-row">
                    <span>Platform Fee (Demo):</span>
                    <span>Rs. 150.00</span>
                </div>
                <div class="summary-row">
                    <span>Worker Fee:</span>
                    <span>Rs. 2,500.00</span>
                </div>
                <div class="summary-row">
                    <span>Total Amount Payable:</span>
                    <span style="color: #10b981;">Rs. 2,650.00</span>
                </div>
            </div>

            <!-- Payment Form -->
            <form id="paymentForm" onsubmit="processPayment(event)">
                
                <h3 style="font-size: 1.2rem; font-weight: 800; margin-bottom: 15px; color: #1a1a1a;">Select Payment Method</h3>
                
                <!-- Payment Toggle Buttons -->
                <div class="payment-methods">
                    <label class="method-card active" id="cardMethodLbl" onclick="selectMethod('card')">
                        <input type="radio" name="payment_method" value="card" checked>
                        <i class="ph-fill ph-check-circle check-icon"></i>
                        <i class="ph-fill ph-credit-card"></i>
                        <span>Pay Online (Card)</span>
                    </label>

                    <label class="method-card" id="cashMethodLbl" onclick="selectMethod('cash')">
                        <input type="radio" name="payment_method" value="cash">
                        <i class="ph-fill ph-check-circle check-icon"></i>
                        <i class="ph-fill ph-money"></i>
                        <span>Pay by Cash</span>
                    </label>
                </div>

                <!-- Card Details (Hidden if Cash is selected) -->
                <div class="card-details-section" id="cardDetailsForm">
                    <div class="form-group">
                        <label>Name on Card</label>
                        <input type="text" class="form-control" placeholder="E.g. JOHN DOE" id="cardName" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Card Number</label>
                        <input type="text" class="form-control" placeholder="0000 0000 0000 0000" maxlength="19" id="cardNumber" required>
                    </div>

                    <div class="d-flex-gap">
                        <div class="form-group">
                            <label>Expiry Date</label>
                            <input type="text" class="form-control" placeholder="MM/YY" maxlength="5" id="cardExpiry" required>
                        </div>
                        <div class="form-group">
                            <label>CVV</label>
                            <input type="password" class="form-control" placeholder="123" maxlength="3" id="cardCvv" required>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit" id="submitBtn">
                    <i class="ph-bold ph-lock-key"></i> Pay Rs. 2,650.00
                </button>

            </form>

        </div>
    </div>
</section>

<!-- Demo JavaScript for Form Toggle and Submission -->
<script>
    function selectMethod(method) {
        const cardSection = document.getElementById('cardDetailsForm');
        const cardLbl = document.getElementById('cardMethodLbl');
        const cashLbl = document.getElementById('cashMethodLbl');
        const submitBtn = document.getElementById('submitBtn');
        
        // Remove active classes
        cardLbl.classList.remove('active');
        cashLbl.classList.remove('active');

        // Required inputs handling
        const cardInputs = cardSection.querySelectorAll('input');

        if (method === 'card') {
            cardLbl.classList.add('active');
            cardSection.classList.remove('hidden');
            submitBtn.innerHTML = '<i class="ph-bold ph-lock-key"></i> Pay Rs. 2,650.00';
            
            // Make card fields required again
            cardInputs.forEach(input => input.required = true);
        } else {
            cashLbl.classList.add('active');
            cardSection.classList.add('hidden');
            submitBtn.innerHTML = '<i class="ph-bold ph-handshake"></i> Confirm Cash Payment';
            
            // Remove required attribute from card fields so form can submit
            cardInputs.forEach(input => input.required = false);
        }
    }

    function processPayment(event) {
        event.preventDefault();
        
        const method = document.querySelector('input[name="payment_method"]:checked').value;
        const btn = document.getElementById('submitBtn');
        const urlParams = new URLSearchParams(window.location.search);
        const jobId = urlParams.get('job_id') || 1;
        
        btn.innerHTML = '<i class="ph-bold ph-spinner" style="animation: spin 1s linear infinite;"></i> Processing...';
        btn.style.opacity = '0.8';
        btn.disabled = true;

        const formData = new FormData();
        formData.append('action', 'update_status');
        formData.append('job_id', jobId);
        formData.append('status', 'completed');

        fetch('../api/jobs.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            alert(method === 'card' ? "Payment Successful! 💳" : "Cash Payment Confirmed! 💵");
            window.location.href = "my-requests.php";
        })
        .catch(err => {
            alert("Payment processed successfully.");
            window.location.href = "my-requests.php";
        });
    }
</script>

<style>
    @keyframes spin { 100% { transform: rotate(360deg); } }
</style>

</body>
</html>