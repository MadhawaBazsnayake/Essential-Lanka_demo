<?php
// how-it-works.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How It Works - Essential Lanka</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        .hiw-section { padding: 60px 5%; min-height: 85vh; background: #f8fafc; position: relative; overflow: hidden; }
        .hiw-container { max-width: 1100px; margin: 0 auto; position: relative; z-index: 10; }
        
        .page-header { text-align: center; margin-bottom: 50px; }
        .page-header h1 { font-size: 3rem; font-weight: 800; color: #1e293b; margin-bottom: 15px; }
        .page-header p { color: #64748b; font-size: 1.15rem; max-width: 600px; margin: 0 auto; line-height: 1.6; }

        /* Toggle Buttons */
        .role-toggle { display: flex; justify-content: center; gap: 15px; margin-bottom: 50px; }
        .toggle-btn { padding: 12px 30px; border-radius: 50px; font-weight: 700; font-size: 1.05rem; cursor: pointer; transition: 0.3s; border: 2px solid transparent; background: #ffffff; color: #64748b; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .toggle-btn.active-client { background: rgba(16,185,129,0.1); color: #10b981; border-color: #10b981; }
        .toggle-btn.active-worker { background: rgba(59,130,246,0.1); color: #3b82f6; border-color: #3b82f6; }
        .toggle-btn:hover { transform: translateY(-2px); }

        /* Steps Grid Layout */
        .steps-wrapper { display: none; animation: fadeIn 0.5s ease-in-out; }
        .steps-wrapper.active { display: block; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .steps-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; position: relative; }
        
        /* Connecting Line for Desktop */
        .steps-grid::before {
            content: ''; position: absolute; top: 45px; left: 50px; right: 50px; height: 3px; background: #e2e8f0; z-index: -1;
        }

        .step-card { background: #ffffff; padding: 40px 30px; border-radius: 25px; text-align: center; border: 1.5px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.03); transition: 0.3s; position: relative; }
        .step-card:hover { transform: translateY(-5px); border-color: #cbd5e1; box-shadow: 0 15px 40px rgba(0,0,0,0.06); }
        
        .step-icon-wrap { width: 90px; height: 90px; border-radius: 50%; background: #f8fafc; display: flex; justify-content: center; align-items: center; font-size: 2.5rem; margin: 0 auto 25px; position: relative; border: 4px solid #ffffff; box-shadow: 0 10px 20px rgba(0,0,0,0.05); }
        .step-number { position: absolute; top: -5px; right: -5px; width: 30px; height: 30px; border-radius: 50%; color: white; display: flex; justify-content: center; align-items: center; font-size: 0.9rem; font-weight: 800; border: 3px solid #ffffff; }

        /* Theme Colors */
        .theme-client .step-icon-wrap { color: #10b981; }
        .theme-client .step-number { background: #10b981; }
        .theme-worker .step-icon-wrap { color: #3b82f6; }
        .theme-worker .step-number { background: #3b82f6; }

        .step-title { font-size: 1.3rem; font-weight: 800; color: #1e293b; margin-bottom: 12px; }
        .step-desc { font-size: 0.95rem; color: #64748b; line-height: 1.6; }

        /* CTA Section */
        .cta-box { margin-top: 60px; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 30px; padding: 50px; text-align: center; color: white; position: relative; overflow: hidden; }
        .cta-box::after { content: ''; position: absolute; right: -50px; bottom: -50px; width: 200px; height: 200px; background: radial-gradient(circle, rgba(16,185,129,0.2) 0%, transparent 70%); border-radius: 50%; }
        .cta-box h2 { font-size: 2.2rem; font-weight: 800; margin-bottom: 15px; position: relative; z-index: 2; }
        .cta-box p { font-size: 1.1rem; color: #94a3b8; margin-bottom: 30px; position: relative; z-index: 2; }
        
        .cta-btn { background: #10b981; color: white; padding: 15px 35px; border-radius: 50px; font-weight: 800; text-decoration: none; font-size: 1.1rem; transition: 0.3s; display: inline-flex; align-items: center; gap: 10px; position: relative; z-index: 2; border: none; cursor: pointer; }
        .cta-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(16,185,129,0.3); background: #059669; }

        @media (max-width: 992px) {
            .steps-grid::before { display: none; }
        }
        @media (max-width: 768px) {
            .page-header h1 { font-size: 2.2rem; }
            .role-toggle { flex-direction: column; padding: 0 20px; }
        }
    </style>
</head>
<body>

<!-- Navigation Bar can be included here -->

<section class="hiw-section">
    <div class="blob-bg"></div>
    
    <div class="hiw-container">
        
        <div class="page-header">
            <h1>How Essential Lanka Works</h1>
            <p>Your one-stop platform for everyday services. Whether you need a task done or you want to offer your skills, we've made it simple and secure.</p>
        </div>

        <div class="role-toggle">
            <button class="toggle-btn active-client" id="btn-client" onclick="showSteps('client')"><i class="ph-bold ph-user"></i> I need a service (Customer)</button>
            <button class="toggle-btn" id="btn-worker" onclick="showSteps('worker')"><i class="ph-bold ph-wrench"></i> I offer services (Professional)</button>
        </div>

        <!-- CLIENT STEPS -->
        <div class="steps-wrapper active theme-client" id="client-steps">
            <div class="steps-grid">
                
                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-note-pencil"></i>
                        <div class="step-number">1</div>
                    </div>
                    <h3 class="step-title">Post a Job</h3>
                    <p class="step-desc">Describe what you need done. Add photos, set a budget, and share your location to get accurate responses.</p>
                </div>

                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-files"></i>
                        <div class="step-number">2</div>
                    </div>
                    <h3 class="step-title">Receive Bids</h3>
                    <p class="step-desc">Verified professionals in your area will see your request and send you competitive bids and proposals.</p>
                </div>

                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-handshake"></i>
                        <div class="step-number">3</div>
                    </div>
                    <h3 class="step-title">Hire & Chat</h3>
                    <p class="step-desc">Compare profiles, read reviews, and hire the best fit. Chat or call them directly through our secure platform.</p>
                </div>

                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-star"></i>
                        <div class="step-number">4</div>
                    </div>
                    <h3 class="step-title">Job Done & Rate</h3>
                    <p class="step-desc">Once the job is completed to your satisfaction, leave a rating and review to help others in the community.</p>
                </div>

            </div>
        </div>

        <!-- WORKER STEPS -->
        <div class="steps-wrapper theme-worker" id="worker-steps">
            <div class="steps-grid">
                
                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-identification-card"></i>
                        <div class="step-number">1</div>
                    </div>
                    <h3 class="step-title">Create a Profile</h3>
                    <p class="step-desc">Sign up as a worker. Complete your profile, verify your identity, and list your specialized services (Gigs).</p>
                </div>

                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-magnifying-glass"></i>
                        <div class="step-number">2</div>
                    </div>
                    <h3 class="step-title">Browse & Bid</h3>
                    <p class="step-desc">Find job requests near your location. Send customized bids to clients explaining why you are the best fit.</p>
                </div>

                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-briefcase"></i>
                        <div class="step-number">3</div>
                    </div>
                    <h3 class="step-title">Get Hired</h3>
                    <p class="step-desc">When a client accepts your bid, you'll be notified instantly. Use the built-in chat to finalize details.</p>
                </div>

                <div class="step-card">
                    <div class="step-icon-wrap">
                        <i class="ph-fill ph-wallet"></i>
                        <div class="step-number">4</div>
                    </div>
                    <h3 class="step-title">Earn & Grow</h3>
                    <p class="step-desc">Complete the job, get paid directly, and earn 5-star reviews to boost your profile and win more jobs.</p>
                </div>

            </div>
        </div>

        <!-- Call to Action -->
        <div class="cta-box">
            <h2>Ready to get started?</h2>
            <p>Join thousands of Sri Lankans who trust Essential Lanka for their daily needs.</p>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?php echo ($_SESSION['role'] === 'worker') ? 'worker/dashboard.php' : 'client/dashboard.php'; ?>" class="cta-btn">
                    <i class="ph-bold ph-rocket-launch"></i> Go to Dashboard
                </a>
            <?php else: ?>
                <a href="login.php" class="cta-btn">
                    <i class="ph-bold ph-sign-in"></i> Sign Up / Login Now
                </a>
            <?php endif; ?>
        </div>

    </div>
</section>

<script>
    function showSteps(role) {
        // Handle Buttons
        document.getElementById('btn-client').classList.remove('active-client');
        document.getElementById('btn-worker').classList.remove('active-worker');
        
        if(role === 'client') {
            document.getElementById('btn-client').classList.add('active-client');
        } else {
            document.getElementById('btn-worker').classList.add('active-worker');
        }

        // Handle Content
        document.getElementById('client-steps').classList.remove('active');
        document.getElementById('worker-steps').classList.remove('active');
        
        document.getElementById(role + '-steps').classList.add('active');
    }
</script>

</body>
</html>