<?php
// privacy.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Essential Lanka</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        .privacy-section { padding: 60px 5%; min-height: 85vh; background: #f8fafc; position: relative; }
        .privacy-container { max-width: 900px; margin: 0 auto; position: relative; z-index: 10; }
        
        .page-header { text-align: center; margin-bottom: 40px; }
        .page-header h1 { font-size: 2.8rem; font-weight: 800; color: #1e293b; margin-bottom: 15px; }
        .page-header p { color: #64748b; font-size: 1.1rem; }

        .glass-box { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(25px); border: 1.5px solid rgba(255, 255, 255, 0.9); box-shadow: 0 15px 40px rgba(0,0,0,0.05); padding: 50px; border-radius: 30px; }
        
        .last-updated { display: inline-block; background: rgba(59,130,246,0.1); color: #3b82f6; padding: 6px 15px; border-radius: 50px; font-size: 0.85rem; font-weight: 700; margin-bottom: 30px; }

        .policy-block { margin-bottom: 35px; }
        .policy-block:last-child { margin-bottom: 0; }
        
        .policy-title { font-size: 1.4rem; font-weight: 800; color: #1e293b; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
        .policy-title i { color: #10b981; font-size: 1.6rem; }
        
        .policy-text { font-size: 1rem; color: #475569; line-height: 1.8; margin-bottom: 15px; }
        .policy-list { list-style: none; padding-left: 0; margin-bottom: 15px; }
        .policy-list li { position: relative; padding-left: 25px; margin-bottom: 10px; color: #475569; line-height: 1.6; }
        .policy-list li::before { content: '•'; position: absolute; left: 0; color: #3b82f6; font-weight: bold; font-size: 1.2rem; line-height: 1; top: 0px; }

        .btn-back { display: inline-flex; align-items: center; gap: 8px; color: #1a1a1a; text-decoration: none; font-weight: 700; transition: 0.3s; margin-bottom: 20px; background: #ffffff; padding: 10px 20px; border-radius: 50px; border: 1.5px solid #e2e8f0; box-shadow: 0 5px 15px rgba(0,0,0,0.03); }
        .btn-back:hover { border-color: #3b82f6; color: #3b82f6; transform: translateX(-5px); }

        @media (max-width: 768px) {
            .glass-box { padding: 30px 20px; }
            .page-header h1 { font-size: 2.2rem; }
        }
    </style>
</head>
<body>

<section class="privacy-section">
    <div class="blob-bg"></div>
    
    <div class="privacy-container fade-up show">
        
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="<?php echo ($_SESSION['role'] === 'worker') ? 'worker/dashboard.php' : 'client/dashboard.php'; ?>" class="btn-back">
                <i class="ph-bold ph-arrow-left"></i> Back to Dashboard
            </a>
        <?php else: ?>
            <a href="index.php" class="btn-back">
                <i class="ph-bold ph-arrow-left"></i> Back to Home
            </a>
        <?php endif; ?>

        <div class="page-header">
            <h1>Privacy Policy</h1>
            <p>Your privacy and data security are our top priorities.</p>
        </div>

        <div class="glass-box">
            <span class="last-updated">Last Updated: August 09, 2026</span>

            <div class="policy-block">
                <h2 class="policy-title"><i class="ph-fill ph-info"></i> 1. Information We Collect</h2>
                <p class="policy-text">To provide you with a reliable and secure service platform, we collect the following types of information when you use Essential Lanka:</p>
                <ul class="policy-list">
                    <li><strong>Personal Details:</strong> Your name, phone number, and profile picture.</li>
                    <li><strong>Verification Data:</strong> For workers, National Identity Card (NIC) numbers and location coordinates to verify identity and build trust.</li>
                    <li><strong>Location Data:</strong> Real-time location data (only when shared explicitly via our chat or job posting features) to connect clients with nearby professionals.</li>
                    <li><strong>Communications:</strong> Chat messages, attachments, and call logs (metadata only) facilitated through our platform for dispute resolution and safety.</li>
                </ul>
            </div>

            <div class="policy-block">
                <h2 class="policy-title"><i class="ph-fill ph-gear"></i> 2. How We Use Your Information</h2>
                <p class="policy-text">We use the data we collect solely to operate, maintain, and improve the Essential Lanka platform. Specifically, we use your data to:</p>
                <ul class="policy-list">
                    <li>Match customers with the most suitable and nearby service professionals.</li>
                    <li>Facilitate secure communication (Messages and WebRTC calls) between users.</li>
                    <li>Verify the identity of professionals to ensure a safe environment for all users.</li>
                    <li>Process transactions, bids, and maintain a history of completed jobs.</li>
                </ul>
            </div>

            <div class="policy-block">
                <h2 class="policy-title"><i class="ph-fill ph-share-network"></i> 3. Data Sharing and Disclosure</h2>
                <p class="policy-text">We do not sell, rent, or trade your personal information to third parties. Your information is only shared in the following scenarios:</p>
                <ul class="policy-list">
                    <li><strong>Between Users:</strong> When a customer posts a job or accepts a bid, limited profile details (Name, Profile Picture, and general location) are shared with the respective professional, and vice versa.</li>
                    <li><strong>Legal Requirements:</strong> If required by Sri Lankan law, legal processes, or government requests, we may disclose necessary information.</li>
                </ul>
            </div>

            <div class="policy-block">
                <h2 class="policy-title"><i class="ph-fill ph-shield-check"></i> 4. Data Security</h2>
                <p class="policy-text">We implement strict technical and organizational security measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction. Passwords are securely hashed using modern cryptographic algorithms (Bcrypt), and communication channels are secured.</p>
            </div>

            <div class="policy-block">
                <h2 class="policy-title"><i class="ph-fill ph-user-circle"></i> 5. Your Rights</h2>
                <p class="policy-text">You have the right to access, update, or delete your personal information at any time through your Account Dashboard. If you wish to permanently delete your account and associated data from our systems, you can contact our support team.</p>
            </div>

            <div class="policy-block">
                <h2 class="policy-title"><i class="ph-fill ph-envelope-simple"></i> 6. Contact Us</h2>
                <p class="policy-text">If you have any questions or concerns regarding this Privacy Policy or how your data is handled, please contact us at:</p>
                <p class="policy-text">
                    <strong>Email:</strong> privacy@essentiallanka.lk<br>
                    <strong>Hotline:</strong> +94 11 234 5678<br>
                    <strong>Address:</strong> Essential Lanka HQ, Colombo 07, Sri Lanka.
                </p>
            </div>

        </div>
    </div>
</section>

</body>
</html>