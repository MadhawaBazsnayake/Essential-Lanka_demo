<?php
// about.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Essential Lanka</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<style>
    .page-section { padding: 60px 5%; min-height: 85vh; position: relative; overflow: hidden; }
    .page-container { max-width: 1100px; margin: 0 auto; position: relative; z-index: 10; }
    
    .header-action { text-align: center; margin-bottom: 50px; }
    .page-title { font-size: 3rem; font-weight: 800; color: #1a1a1a; margin-bottom: 15px; }
    .page-subtitle { font-size: 1.15rem; color: #666; max-width: 700px; margin: 0 auto; line-height: 1.6; }
    .back-btn { display: inline-flex; align-items: center; gap: 8px; color: #666; text-decoration: none; font-weight: 700; transition: 0.3s; font-size: 1.05rem; margin-bottom: 20px; }
    .back-btn:hover { color: #10b981; }

    .glass-box { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(25px); border: 1px solid rgba(255, 255, 255, 0.9); box-shadow: 0 15px 40px rgba(0,0,0,0.06); padding: 45px; border-radius: 35px; margin-bottom: 40px; }
    
    /* Mission & Vision Layout */
    .mission-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; align-items: center; }
    .mission-content h2 { font-size: 2rem; font-weight: 800; color: #1a1a1a; margin-bottom: 20px; }
    .mission-content p { font-size: 1.05rem; color: #4a4a4a; line-height: 1.8; margin-bottom: 15px; }
    
    .mission-image { width: 100%; height: 350px; background-image: url('https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=800&auto=format&fit=crop'); background-size: cover; background-position: center; border-radius: 25px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }

    /* Services Grid */
    .section-heading { text-align: center; font-size: 2.2rem; font-weight: 800; color: #1a1a1a; margin-bottom: 40px; }
    .services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; }
    
    .service-card { background: #ffffff; border: 1.5px solid #f0ebe1; padding: 30px; border-radius: 25px; transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    .service-card:hover { border-color: #10b981; box-shadow: 0 15px 35px rgba(16,185,129,0.1); transform: translateY(-5px); }
    
    .service-icon { width: 65px; height: 65px; background: rgba(16, 185, 129, 0.1); color: #10b981; border-radius: 18px; display: flex; justify-content: center; align-items: center; font-size: 2.2rem; margin-bottom: 20px; }
    .service-card h3 { font-size: 1.3rem; font-weight: 800; color: #1a1a1a; margin-bottom: 10px; }
    .service-card p { font-size: 0.95rem; color: #666; line-height: 1.6; }

    /* Why Choose Us Features */
    .features-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 30px; text-align: center; }
    .feature-item { padding: 20px; }
    .feature-icon { font-size: 3rem; color: #3b82f6; margin-bottom: 15px; }
    .feature-item h4 { font-size: 1.2rem; font-weight: 800; color: #1a1a1a; margin-bottom: 10px; }
    .feature-item p { font-size: 0.95rem; color: #666; line-height: 1.6; }

    @media (max-width: 992px) {
        .mission-grid { grid-template-columns: 1fr; }
        .mission-image { height: 300px; order: -1; }
        .features-grid { grid-template-columns: 1fr; gap: 15px; }
    }
    @media (max-width: 768px) {
        .page-title { font-size: 2.2rem; }
        .glass-box { padding: 30px 20px; }
    }
</style>

<section class="page-section bg-cream">
    <div class="blob-bg"></div>
    
    <div class="page-container">
        
        <div class="header-action fade-up show">
            <a href="index.php" class="back-btn"><i class="ph-bold ph-arrow-left"></i> Back to Home</a>
            <h1 class="page-title">About Essential Lanka</h1>
            <p class="page-subtitle">Connecting skilled local professionals with customers who need reliable, fast, and high-quality handyman services across Sri Lanka.</p>
        </div>

        <!-- Mission & Vision Section -->
        <div class="glass-box fade-up show" style="transition-delay: 100ms;">
            <div class="mission-grid">
                <div class="mission-content">
                    <h2>Our Mission</h2>
                    <p>At <strong>Essential Lanka</strong>, we believe that finding a trustworthy professional for your household repairs should not be a hassle. Our platform serves as a secure bridge, empowering skilled local workers to find consistent jobs while giving homeowners peace of mind.</p>
                    <p>We thoroughly verify every worker's identity and maintain a transparent rating system, ensuring that you always get the best service possible, exactly when you need it.</p>
                </div>
                <div class="mission-image"></div>
            </div>
        </div>

        <!-- What We Do / Services Section -->
        <h2 class="section-heading fade-up show">Services We Offer</h2>
        <div class="services-grid fade-up show" style="transition-delay: 200ms;">
            
            <div class="service-card">
                <div class="service-icon"><i class="ph-fill ph-lightning"></i></div>
                <h3>Electrical Works</h3>
                <p>From simple wiring repairs to complete house electrical installations, our certified electricians are ready to handle it safely.</p>
            </div>

            <div class="service-card">
                <div class="service-icon" style="color: #3b82f6; background: rgba(59, 130, 246, 0.1);"><i class="ph-fill ph-drop"></i></div>
                <h3>Plumbing Solutions</h3>
                <p>Fixing leaks, installing water pumps, and maintaining bathroom pipelines done efficiently by experienced plumbers.</p>
            </div>

            <div class="service-card">
                <div class="service-icon" style="color: #f59e0b; background: rgba(245, 158, 11, 0.1);"><i class="ph-fill ph-hammer"></i></div>
                <h3>Carpentry & Woodwork</h3>
                <p>Custom furniture building, door & window repairs, and general carpentry services to enhance your living space.</p>
            </div>

            <div class="service-card">
                <div class="service-icon" style="color: #8b5cf6; background: rgba(139, 92, 246, 0.1);"><i class="ph-fill ph-broom"></i></div>
                <h3>Cleaning & Maintenance</h3>
                <p>Professional home and office cleaning, roof cleaning, and general property maintenance services.</p>
            </div>

        </div>

        <!-- Why Choose Us Section -->
        <div class="glass-box fade-up show" style="margin-top: 40px; transition-delay: 300ms;">
            <h2 class="section-heading" style="margin-bottom: 30px;">Why Choose Us?</h2>
            
            <div class="features-grid">
                <div class="feature-item">
                    <i class="ph-fill ph-shield-check feature-icon" style="color: #10b981;"></i>
                    <h4>Verified Professionals</h4>
                    <p>Every worker on our platform undergoes a strict NIC verification process to ensure your safety and trust.</p>
                </div>
                
                <div class="feature-item">
                    <i class="ph-fill ph-star feature-icon" style="color: #f59e0b;"></i>
                    <h4>Transparent Ratings</h4>
                    <p>Make informed decisions by reading genuine reviews and ratings left by previous customers.</p>
                </div>
                
                <div class="feature-item">
                    <i class="ph-fill ph-credit-card feature-icon" style="color: #3b82f6;"></i>
                    <h4>Secure & Easy Process</h4>
                    <p>Post a job, receive bids, select your preferred worker, and manage payments easily through our interactive dashboard.</p>
                </div>
            </div>
        </div>

    </div>
</section>

</body>
</html>